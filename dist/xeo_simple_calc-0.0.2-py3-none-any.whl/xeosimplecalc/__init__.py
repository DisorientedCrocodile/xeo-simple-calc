def add(a, b):
    return a + b
def subtract(a, b):
    return a - b
def multiply(a, b):
    return a * b
def float_divide(a, b):
    return a / b
def int_divide(a, b):
    return int(a/b)